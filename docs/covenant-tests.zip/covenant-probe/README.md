# Covenant prototype + tests

Run inside a clone of https://github.com/Uniswap/liquidity-launcher (commit 266c187, Oct 2026):

1. `git submodule update --init --depth 1` (v4-core, v4-periphery, solady, openzeppelin, permit2, blocknumberish, uerc20-factory)
2. Copy `src/` of https://github.com/Uniswap/continuous-clearing-auction to `lib/cca/src/`
3. Append to `remappings.txt`:
   ```
   continuous-clearing-auction/=lib/cca/src/
   liquidity-launcher/=./
   solady/=lib/solady/src/
   v4-periphery/=lib/v4-periphery/
   ```
4. Put these files in `test/covenant/` and run:
   `FOUNDRY_FFI=false forge test --match-path "test/covenant/*" --code-size-limit 60000 -vv`

Files:
- `Covenant.sol`            prototype hook + vault (all rules)
- `CovenantAttacks.t.sol`   18 adversarial / rule tests
- `CovenantChained.t.sol`   real CCA -> real LBPStrategy -> Covenant -> demand-shaped Seed, plus demand-walk gas
- `CovenantProbe.t.sol`     6 feasibility probes (migration, afterSwap, reshape, ownership, hookless mode, timelock)
- `CovenantDemandCurve.t.sol` (runs in the CCA repo) losing-bid demand readable after the auction
