// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

// Feasibility probe for Covenant's "Seed" step: after a real CCA ends, can the full demand curve,
// INCLUDING bids that lost (max price below the clearing price), still be read on-chain?

import {AuctionBaseTest} from './utils/AuctionBaseTest.sol';
import {Tick} from '../src/interfaces/ITickStorage.sol';

contract CovenantDemandCurveTest is AuctionBaseTest {
    function setUp() public {
        setUpAuction();
        vm.deal(address(this), type(uint128).max);
    }

    function test_demandCurveIncludingLosingBidsIsReadableAfterAuction() public {
        uint256 p2 = tickNumberToPriceX96(2);
        uint256 p3 = tickNumberToPriceX96(3);
        uint256 p6 = tickNumberToPriceX96(6);

        // Two bidders who will be outbid (support demand at lower prices)
        uint128 loser2 = inputAmountForTokens(300e18, p2);
        auction.submitBid{value: loser2}(p2, loser2, bob, tickNumberToPriceX96(1), bytes(''));
        uint128 loser3 = inputAmountForTokens(300e18, p3);
        auction.submitBid{value: loser3}(p3, loser3, bob, p2, bytes(''));
        // One large bidder who pushes the clearing price above both
        uint128 winner6 = inputAmountForTokens(1200e18, p6);
        auction.submitBid{value: winner6}(p6, winner6, alice, p3, bytes(''));

        vm.roll(auction.endBlock());
        auction.checkpoint();
        uint256 clearing = auction.clearingPrice();
        emit log_named_uint('clearing price (tick units)', (clearing - FLOOR_PRICE) / TICK_SPACING + 1);
        assertGt(clearing, p3, 'losing bids are below the clearing price');

        // Walk the on-chain tick list from the floor, exactly as a Covenant Seed step would.
        uint256 price = auction.floorPrice();
        uint256 demandBelowClearing;
        uint256 demandAtOrAboveClearing;
        uint256 levels;
        while (price != type(uint256).max && levels < 100) {
            Tick memory t = auction.ticks(price);
            if (price < clearing) demandBelowClearing += t.currencyDemandQ96;
            else demandAtOrAboveClearing += t.currencyDemandQ96;
            emit log_named_uint('price level (tick units)', (price - FLOOR_PRICE) / TICK_SPACING + 1);
            emit log_named_uint('  recorded currency demand (Q96, scaled)', t.currencyDemandQ96);
            price = t.next;
            levels++;
        }

        assertGt(auction.ticks(p2).currencyDemandQ96, 0, 'losing bid demand at tick 2 still recorded');
        assertGt(auction.ticks(p3).currencyDemandQ96, 0, 'losing bid demand at tick 3 still recorded');
        assertGt(demandBelowClearing, 0, 'outbid demand curve readable');
        assertGt(demandAtOrAboveClearing, 0, 'cleared demand readable');
        emit log_named_uint('price levels walked', levels);
    }
}
